discrete_id = 1
relay_id    = 1